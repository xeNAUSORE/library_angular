export interface Address {
    id: number,
    number: number,
    apt: string,
    street: string,
    city: string,
    zip: string,
    country: string,
}
