export const environment = {
	// Careful, must NOT end with /
	BASE_API_URL: 'https://localhost:7019/api'
};
  